# CampusGenie 🎓

AI-Powered Smart Student Assistant

## Technologies
- Python
- Streamlit
- Generative AI (Gemini)
- Retrieval-Augmented Generation (RAG)
- Machine Learning
- Data Science

## Features
- AI Study Assistant
- PDF Question Answering
- Smart Notes Generator
- AI Quiz Generator
- Student Performance Analytics
- ML-based Marks Prediction

## Installation

```bash
pip install -r requirements.txt
```

## Run Application

```bash
streamlit run app.py
```

## Team Project
Developed by a team of four students.
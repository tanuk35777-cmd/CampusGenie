
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO

from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

st.set_page_config(
    page_title="CampusGenie",
    page_icon="🎓",
    layout="wide"
)

# ---------------- SESSION STATE ----------------

if "documents" not in st.session_state:
    st.session_state.documents = []

# ---------------- AI FUNCTION ----------------

def generate_ai(prompt, api_key, fallback=""):
    if not api_key:
        return (
            "Gemini API key not provided. Here is the available "
            "document content instead:\n\n" + fallback
            if fallback else
            "Please enter your Gemini API key in the sidebar to use AI."
        )

    try:
        from google import genai

        client = genai.Client(api_key=api_key)

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        return response.text or "No response generated."

    except Exception as e:
        return f"AI error: {str(e)}"

# ---------------- PDF EXTRACTION ----------------

def extract_text(uploaded_file):
    if uploaded_file.name.lower().endswith(".pdf"):
        reader = PdfReader(BytesIO(uploaded_file.getvalue()))
        text = ""

        for page in reader.pages:
            text += (page.extract_text() or "") + "\n"

        return text

    elif uploaded_file.name.lower().endswith(".txt"):
        return uploaded_file.getvalue().decode(
            "utf-8", errors="ignore"
        )

    return ""

# ---------------- TEXT CHUNKING ----------------

def split_text(text, size=900, overlap=150):
    text = " ".join(text.split())

    chunks = []

    start = 0

    while start < len(text):
        end = min(start + size, len(text))

        chunks.append(text[start:end])

        if end == len(text):
            break

        start = end - overlap

    return chunks

# ---------------- RAG RETRIEVAL ----------------

def retrieve_documents(question, documents, top_k=4):

    if not documents:
        return "", []

    texts = [doc["text"] for doc in documents]

    try:
        vectorizer = TfidfVectorizer(
            stop_words="english"
        )

        matrix = vectorizer.fit_transform(
            texts + [question]
        )

        scores = cosine_similarity(
            matrix[-1], matrix[:-1]
        ).flatten()

        best = scores.argsort()[::-1][:top_k]

        selected = [
            i for i in best if scores[i] > 0
        ]

        context = "\n\n".join(
            documents[i]["text"] for i in selected
        )

        sources = list(dict.fromkeys(
            documents[i]["source"] for i in selected
        ))

        return context, sources

    except ValueError:
        return "", []

# ---------------- SAMPLE STUDENT DATA ----------------

def create_student_data():

    return pd.DataFrame({
        "student_id": [f"S{i:03d}" for i in range(1, 31)],

        "attendance": [
            92,75,88,60,95,70,82,55,90,78,
            68,98,85,72,62,89,80,67,94,76,
            83,73,91,64,87,79,96,69,84,58
        ],

        "study_hours": [
            4,2,3.5,1,5,2.5,3,1.5,4.5,2.8,
            2,6,3.2,2.2,1.8,4,3,1.5,5,2.5,
            3.5,2.3,4.2,1.7,3.8,2.9,5.5,2.1,3.6,1.2
        ],

        "previous_marks": [
            82,65,78,52,90,60,72,48,85,69,
            58,93,75,63,55,80,70,57,88,66,
            76,64,87,54,81,71,92,59,79,50
        ],

        "final_marks": [
            88,68,83,55,94,64,76,50,91,72,
            61,97,80,66,57,86,74,59,93,70,
            79,67,90,56,85,75,96,62,82,53
        ]
    })

# ---------------- MACHINE LEARNING ----------------

def train_ml_model(data):

    features = [
        "attendance",
        "study_hours",
        "previous_marks"
    ]

    X = data[features]
    y = data["final_marks"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.25,
        random_state=42
    )

    model = RandomForestRegressor(
        n_estimators=100,
        random_state=42
    )

    model.fit(X_train, y_train)

    accuracy = model.score(X_test, y_test)

    return model, accuracy

# ---------------- SIDEBAR ----------------

st.sidebar.title("🎓 CampusGenie")

st.sidebar.write(
    "Your AI-powered academic assistant"
)

api_key = st.sidebar.text_input(
    "Gemini API Key (optional)",
    type="password"
)

page = st.sidebar.radio(
    "Navigate",
    [
        "Home",
        "AI Study Assistant",
        "Smart Notes",
        "AI Quiz Generator",
        "Student Analytics"
    ]
)

st.sidebar.divider()

st.sidebar.caption(
    "Built using Python, RAG, Gen AI and ML"
)

# ---------------- HOME PAGE ----------------

if page == "Home":

    st.title("🎓 Welcome to CampusGenie")

    st.subheader(
        "Your Personal AI Academic Assistant"
    )

    st.write(
        "CampusGenie combines Artificial Intelligence, "
        "Machine Learning and Data Science to help students "
        "study smarter."
    )

    c1, c2, c3 = st.columns(3)

    c1.metric("Core Technologies", "3")
    c2.metric("Study Modules", "3")
    c3.metric("ML Module", "1")

    st.divider()

    st.subheader("Our Features")

    col1, col2 = st.columns(2)

    with col1:
        st.info("📚 AI Study Assistant\n\nAsk questions from your PDFs.")

        st.info("📝 Smart Notes\n\nGenerate summaries and revision notes.")

        st.info("🧠 AI Quiz Generator\n\nCreate practice MCQs.")

    with col2:
        st.success("📊 Student Analytics\n\nExplore student performance.")

        st.success("🔮 ML Prediction\n\nEstimate academic marks.")

    st.caption(
        "Upload your documents in AI Study Assistant to get started."
    )

# ---------------- AI STUDY ASSISTANT ----------------

elif page == "AI Study Assistant":

    st.title("📚 AI Study Assistant")

    st.write(
        "Upload your academic PDF or TXT files "
        "and ask questions about their contents."
    )

    uploaded_files = st.file_uploader(
        "Upload study documents",
        type=["pdf", "txt"],
        accept_multiple_files=True
    )

    if uploaded_files:

        if st.button("Process Documents"):

            for file in uploaded_files:

                try:
                    text = extract_text(file)

                    chunks = split_text(text)

                    if not chunks:
                        st.warning(
                            f"No readable text found in {file.name}"
                        )
                        continue

                    for chunk in chunks:
                        st.session_state.documents.append({
                            "source": file.name,
                            "text": chunk
                        })

                    st.success(
                        f"{file.name} processed successfully!"
                    )

                except Exception as e:
                    st.error(str(e))

    st.write(
        f"Total document chunks: "
        f"{len(st.session_state.documents)}"
    )

    if st.button("Clear Documents"):
        st.session_state.documents = []
        st.rerun()

    st.divider()

    question = st.text_input(
        "Ask your question",
        placeholder="Explain inheritance in Java..."
    )

    if st.button("Generate Answer"):

        if not question.strip():
            st.warning("Enter a question first.")

        elif not st.session_state.documents:
            st.warning("Upload a document first.")

        else:

            with st.spinner("Searching documents..."):

                context, sources = retrieve_documents(
                    question,
                    st.session_state.documents
                )

                if not context:
                    st.warning(
                        "No relevant information found in the documents."
                    )

                else:

                    prompt = f"""
                    You are CampusGenie, an academic assistant.

                    Answer the student's question using ONLY
                    the provided document context.

                    Explain in simple student-friendly language.

                    If the answer is not available in the context,
                    clearly say that the uploaded material does
                    not contain enough information.

                    CONTEXT:
                    {context}

                    QUESTION:
                    {question}
                    """

                    answer = generate_ai(
                        prompt,
                        api_key,
                        context
                    )

                    st.subheader("🤖 AI Answer")

                    st.write(answer)

                    st.subheader("📖 Retrieved Sources")

                    for source in sources:
                        st.write("•", source)

# ---------------- SMART NOTES ----------------

elif page == "Smart Notes":

    st.title("📝 Smart Notes Generator")

    if not st.session_state.documents:

        st.warning(
            "Upload study documents in AI Study Assistant first."
        )

    else:

        note_type = st.selectbox(
            "Choose notes format",
            [
                "Short Summary",
                "Exam Revision Notes",
                "Detailed Notes",
                "Important Points"
            ]
        )

        if st.button("Generate Notes"):

            context = "\n\n".join(
                d["text"] for d in st.session_state.documents
            )[:12000]

            prompt = f"""
            Create {note_type} from the following study material.

            Use simple language and headings.
            Use bullet points.
            Do not add unsupported facts.

            STUDY MATERIAL:
            {context}
            """

            with st.spinner("Generating notes..."):

                notes = generate_ai(
                    prompt,
                    api_key,
                    context
                )

            st.subheader("Your Notes")

            st.write(notes)

            st.download_button(
                "Download Notes",
                notes,
                file_name="CampusGenie_Notes.txt"
            )

# ---------------- AI QUIZ GENERATOR ----------------

elif page == "AI Quiz Generator":

    st.title("🧠 AI Quiz Generator")

    if not st.session_state.documents:

        st.warning(
            "Upload study documents in AI Study Assistant first."
        )

    else:

        number = st.slider(
            "Number of MCQs",
            min_value=3,
            max_value=15,
            value=5
        )

        if st.button("Generate Quiz"):

            context = "\n\n".join(
                d["text"] for d in st.session_state.documents
            )[:12000]

            prompt = f"""
            Generate {number} multiple-choice questions
            using ONLY the following study material.

            Each question must have:
            1. A question
            2. Four options A, B, C and D
            3. One correct answer
            4. A short explanation

            Keep the questions suitable for university students.

            MATERIAL:
            {context}
            """

            with st.spinner("Creating questions..."):

                quiz = generate_ai(
                    prompt,
                    api_key,
                    context
                )

            st.subheader("Your Practice Quiz")

            st.write(quiz)

            st.download_button(
                "Download Quiz",
                quiz,
                file_name="CampusGenie_Quiz.txt"
            )

# ---------------- STUDENT ANALYTICS ----------------

elif page == "Student Analytics":

    st.title("📊 Student Performance Analytics")

    st.write(
        "Analyse attendance, study hours and marks "
        "using Data Science and Machine Learning."
    )

    st.subheader("Upload Student Dataset")

    uploaded_csv = st.file_uploader(
        "Upload CSV (optional)",
        type=["csv"]
    )

    if uploaded_csv:

        data = pd.read_csv(uploaded_csv)

    else:

        data = create_student_data()

        st.info(
            "Showing demonstration data. "
            "These records are synthetic."
        )

    required = [
        "attendance",
        "study_hours",
        "previous_marks",
        "final_marks"
    ]

    if not all(col in data.columns for col in required):

        st.error(
            "CSV must contain: " + ", ".join(required)
        )

    elif len(data) < 5:

        st.error(
            "At least five complete student records are needed."
        )

    else:

        data = data.dropna(subset=required)

        if len(data) < 5:
            st.error("Not enough valid student records.")
            st.stop()

        st.subheader("Student Dataset")

        st.dataframe(
            data,
            use_container_width=True
        )

        c1, c2, c3 = st.columns(3)

        c1.metric(
            "Average Attendance",
            f"{data['attendance'].mean():.1f}%"
        )

        c2.metric(
            "Average Study Hours",
            f"{data['study_hours'].mean():.1f}"
        )

        c3.metric(
            "Average Final Marks",
            f"{data['final_marks'].mean():.1f}"
        )

        st.divider()

        st.subheader("📈 Data Visualization")

        fig, ax = plt.subplots()

        ax.scatter(
            data["attendance"],
            data["final_marks"]
        )

        ax.set_xlabel("Attendance (%)")
        ax.set_ylabel("Final Marks")
        ax.set_title("Attendance vs Final Marks")

        st.pyplot(fig)

        fig2, ax2 = plt.subplots()

        ax2.bar(
            data["student_id"].astype(str)
            if "student_id" in data.columns
            else data.index.astype(str),
            data["final_marks"]
        )

        ax2.set_xlabel("Student")
        ax2.set_ylabel("Final Marks")
        ax2.set_title("Student Marks Comparison")

        ax2.tick_params(
            axis="x",
            rotation=90
        )

        st.pyplot(fig2)

        st.divider()

        st.subheader("🤖 Machine Learning Model")

        model, score = train_ml_model(data)

        st.write(
            f"Model R² score on test data: {score:.3f}"
        )

        st.caption(
            "A small demonstration dataset may produce unstable "
            "scores. This is not a validated academic prediction model."
        )

        st.subheader("🔮 Predict Final Marks")

        col1, col2, col3 = st.columns(3)

        with col1:
            attendance = st.slider(
                "Attendance (%)",
                0, 100, 80
            )

        with col2:
            hours = st.slider(
                "Daily Study Hours",
                0.0, 12.0, 3.0, 0.5
            )

        with col3:
            previous = st.slider(
                "Previous Marks",
                0, 100, 70
            )

        if st.button("Predict Performance"):

            prediction = model.predict(
                pd.DataFrame([{
                    "attendance": attendance,
                    "study_hours": hours,
                    "previous_marks": previous
                }])
            )[0]

            prediction = max(
                0, min(100, prediction)
            )

            st.success(
                f"Estimated Final Marks: {prediction:.2f}/100"
            )

            st.caption(
                "This is an educational estimate, not a guaranteed result."
            )

# ---------------- FOOTER ----------------

st.divider()

st.caption(
    "CampusGenie | Data Science + Machine Learning + RAG + Generative AI"
)
